"""
LeadPilot — Meta Marketing & Graph API Service.

Handles Facebook OAuth flow, 60-day token exchange, asset fetching (BM,
Ad Accounts, Pages, Pixels), and automated asset diagnostics.
"""
from typing import Dict, Any, List, Optional
import httpx
from datetime import datetime
from bson import ObjectId

from app.config import settings
from app.db.mongodb import support_tickets_collection, notifications_collection
from app.core.exceptions import MetaAPIError

GRAPH_API_URL = "https://graph.facebook.com/v19.0"
SCOPES = [
    "ads_management",
    "pages_read_engagement",
    "pages_show_list",
    "business_management",
    "ads_read",
    "leads_retrieval",
]


def build_oauth_url(state: str) -> str:
    """Build Facebook OAuth authorization URL."""
    scope_str = ",".join(SCOPES)
    return (
        f"https://www.facebook.com/v19.0/dialog/oauth?"
        f"client_id={settings.META_APP_ID}&"
        f"redirect_uri={settings.META_REDIRECT_URI}&"
        f"scope={scope_str}&"
        f"state={state}&"
        f"response_type=code"
    )


async def exchange_code_for_long_lived_token(code: str) -> str:
    """
    1. Exchange authorization code for a short-lived access token.
    2. Exchange short-lived token for a 60-day long-lived access token.
    """
    if not settings.META_APP_ID or not settings.META_APP_SECRET:
        # Development fallback / Sandbox mock token
        return f"mock_long_lived_token_{code}"

    async with httpx.AsyncClient() as client:
        # Step 1: Code -> Short-lived token
        token_res = await client.get(
            f"{GRAPH_API_URL}/oauth/access_token",
            params={
                "client_id": settings.META_APP_ID,
                "redirect_uri": settings.META_REDIRECT_URI,
                "client_secret": settings.META_APP_SECRET,
                "code": code,
            },
        )
        if token_res.status_code != 200:
            raise MetaAPIError(f"Failed to exchange OAuth code: {token_res.text}")

        short_token = token_res.json().get("access_token")

        # Step 2: Short token -> 60-day Long-lived token
        long_token_res = await client.get(
            f"{GRAPH_API_URL}/oauth/access_token",
            params={
                "grant_type": "fb_exchange_token",
                "client_id": settings.META_APP_ID,
                "client_secret": settings.META_APP_SECRET,
                "fb_exchange_token": short_token,
            },
        )
        if long_token_res.status_code != 200:
            return short_token  # Fallback to short-lived if exchange fails

        return long_token_res.json().get("access_token", short_token)


async def fetch_user_businesses(access_token: str) -> List[Dict[str, Any]]:
    """Fetch Business Managers owned or managed by the user."""
    if access_token.startswith("mock_"):
        return [{"id": "bm_981247129", "name": "Candle Craft Business"}]

    async with httpx.AsyncClient() as client:
        res = await client.get(
            f"{GRAPH_API_URL}/me/businesses",
            params={"access_token": access_token, "fields": "id,name"},
        )
        if res.status_code != 200:
            return []
        return res.json().get("data", [])


async def fetch_user_ad_accounts(access_token: str) -> List[Dict[str, Any]]:
    """Fetch Meta Ad Accounts accessible by the user."""
    if access_token.startswith("mock_"):
        return [{"id": "act_40912401", "name": "Candle Craft Main Ad Acc", "account_status": 1, "currency": "INR"}]

    async with httpx.AsyncClient() as client:
        res = await client.get(
            f"{GRAPH_API_URL}/me/adaccounts",
            params={"access_token": access_token, "fields": "id,name,account_status,currency"},
        )
        if res.status_code != 200:
            return []
        return res.json().get("data", [])


async def fetch_user_pages(access_token: str) -> List[Dict[str, Any]]:
    """Fetch Facebook Pages managed by the user."""
    if access_token.startswith("mock_"):
        return [{"id": "page_88124019", "name": "Candle Craft India", "access_token": "page_token_mock"}]

    async with httpx.AsyncClient() as client:
        res = await client.get(
            f"{GRAPH_API_URL}/me/accounts",
            params={"access_token": access_token, "fields": "id,name,access_token"},
        )
        if res.status_code != 200:
            return []
        return res.json().get("data", [])


async def run_asset_diagnostics(user_id: str, access_token: str) -> Dict[str, Any]:
    """
    Runs diagnostic on fetched Meta assets. If any required asset is missing,
    automatically creates a support ticket and notifies the admin.
    """
    businesses = await fetch_user_businesses(access_token)
    ad_accounts = await fetch_user_ad_accounts(access_token)
    pages = await fetch_user_pages(access_token)

    has_bm = len(businesses) > 0
    has_ad_account = len(ad_accounts) > 0
    has_page = len(pages) > 0

    missing = []
    if not has_ad_account:
        missing.append("Ad Account")
    if not has_page:
        missing.append("Facebook Page")

    if missing:
        # Create automatic support ticket
        ticket_doc = {
            "user_id": ObjectId(user_id) if ObjectId.is_valid(user_id) else user_id,
            "title": f"Missing Meta Assets: {', '.join(missing)}",
            "status": "open",
            "priority": "high",
            "source": "ai_diagnostic",
            "description": f"AI Diagnostic detected missing Meta assets ({', '.join(missing)}) during OAuth onboarding. Support contact required.",
            "created_at": datetime.utcnow(),
            "updated_at": datetime.utcnow(),
        }
        await support_tickets_collection().insert_one(ticket_doc)

        # Notify Admin
        await notifications_collection().insert_one({
            "type": "support_alert",
            "title": "Action Required: Meta Asset Missing",
            "user_id": str(user_id),
            "message": f"User is missing {', '.join(missing)}. Please assist with Meta setup.",
            "created_at": datetime.utcnow(),
        })

    return {
        "has_bm": has_bm,
        "has_ad_account": has_ad_account,
        "has_page": has_page,
        "missing_assets": missing,
        "businesses": businesses,
        "ad_accounts": ad_accounts,
        "pages": pages,
        "message": "Asset diagnostic complete." if not missing else f"Missing assets detected: {', '.join(missing)}",
    }
