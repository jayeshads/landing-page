import { useState, useRef, useEffect, useCallback } from 'react'
import { Helmet } from 'react-helmet-async'
import { useSearchParams } from 'react-router-dom'
import {
  Sparkles, Send, Paperclip, Image, Loader2,
  FileText, X, CheckCircle2, XCircle, Info, PenSquare, Mic,
  PanelLeftClose, PanelLeft, MessageSquare, Trash2, Megaphone
} from 'lucide-react'
import { useAuth } from '@/lib/AuthContext'
import {
  askAiManager, AiManagerError,
  listChatSessions, createChatSession, getChatSessionHistory, deleteChatSession,
  getPendingDraft, approveDraft, rejectDraft,
  type ChatSessionSummary,
} from '@/lib/aiManager'
import { cn } from '@/lib/utils'

interface ChatMessage {
  id?: string
  role: 'user' | 'assistant' | 'error'
  content: string
  created_at?: string
}

interface CampaignDraft {
  id: string
  business_id: string
  status: 'pending' | 'approved' | 'rejected'
  strategy: {
    campaign_name: string
    objective: string
    daily_budget: number
    target_audience: string
    notes?: string
  }
  creative: {
    headline: string
    primary_text: string
    image_url?: string
    filename?: string
  }
  landing_page?: {
    name: string
    template_id: string
    content_json?: Record<string, unknown> | null
  }
}

interface TraceStep {
  decision: {
    action: string
    tool: string
    args?: Record<string, unknown>
  }
}

interface ComposerProps {
  input: string
  setInput: (val: string) => void
  sending: boolean
  attachedImage: string | null
  setAttachedImage: (val: string | null) => void
  attachedFileName: string | null
  setAttachedFileName: (val: string | null) => void
  fileInputRef: React.RefObject<HTMLInputElement>
  textareaRef: React.RefObject<HTMLTextAreaElement>
  handleFileChange: (e: React.ChangeEvent<HTMLInputElement>) => void
  handleSendMessage: (text: string) => void
}

// Textarea grows with content (like Claude/ChatGPT's composer) instead of
// staying a fixed single line — capped so it never takes over the screen.
const TEXTAREA_MAX_HEIGHT = 200

function autoGrow(el: HTMLTextAreaElement | null) {
  if (!el) return
  el.style.height = 'auto'
  el.style.height = `${Math.min(el.scrollHeight, TEXTAREA_MAX_HEIGHT)}px`
}

function Composer({
  input,
  setInput,
  sending,
  attachedImage,
  setAttachedImage,
  attachedFileName,
  setAttachedFileName,
  fileInputRef,
  textareaRef,
  handleFileChange,
  handleSendMessage
}: ComposerProps) {
  useEffect(() => {
    autoGrow(textareaRef.current)
  }, [input, textareaRef])

  return (
    <div className="max-w-3xl mx-auto w-full">
      {attachedImage && (
        <div className="mb-2 flex items-center gap-2 bg-white border border-claude-border p-2 rounded-xl max-w-xs relative">
          <img src={attachedImage} className="w-9 h-9 object-cover rounded-lg border border-claude-border" alt="Attachment thumb" />
          <div className="min-w-0 flex-1">
            <p className="text-xs text-claude-text font-medium truncate">{attachedFileName ?? 'attached_media.png'}</p>
            <p className="text-[10px] text-claude-textMuted">Ready to send</p>
          </div>
          <button
            onClick={() => { setAttachedImage(null); setAttachedFileName(null) }}
            className="absolute -top-1.5 -right-1.5 w-5 h-5 bg-white border border-claude-border text-claude-textMuted hover:text-claude-text rounded-full flex items-center justify-center shadow-sm"
          >
            <X size={10} />
          </button>
        </div>
      )}

      <div className="border border-claude-border bg-white rounded-2xl shadow-sm px-3 pt-3 pb-2 flex flex-col gap-2">
        <input
          ref={fileInputRef}
          type="file"
          accept="image/*"
          onChange={handleFileChange}
          className="hidden"
        />

        <textarea
          ref={textareaRef}
          value={input}
          onChange={e => setInput(e.target.value)}
          onInput={e => autoGrow(e.currentTarget)}
          onKeyDown={e => {
            if (e.key === 'Enter' && !e.shiftKey) {
              e.preventDefault()
              handleSendMessage(input)
            }
          }}
          placeholder="Message LeadPilot…"
          rows={1}
          className="w-full resize-none bg-transparent text-[15px] text-claude-text placeholder-claude-textMuted focus:outline-none overflow-y-auto"
          style={{ maxHeight: TEXTAREA_MAX_HEIGHT, minHeight: 24 }}
        />

        <div className="flex items-center justify-between">
          <div className="flex items-center gap-1">
            <button
              onClick={() => fileInputRef.current?.click()}
              className="w-8 h-8 text-claude-textMuted hover:text-claude-text hover:bg-claude-bg rounded-lg flex items-center justify-center transition-all flex-shrink-0"
              title="Attach a file or image"
            >
              <Paperclip size={16} />
            </button>
            <button
              onClick={() => setInput('/generate-image ')}
              className="w-8 h-8 text-claude-textMuted hover:text-claude-accent hover:bg-claude-bg rounded-lg flex items-center justify-center transition-all flex-shrink-0"
              title="Generate an image"
            >
              <Image size={16} />
            </button>
          </div>

          <div className="flex items-center gap-2">
            <button
              title="Voice input (coming soon)"
              disabled
              className="w-8 h-8 text-claude-textMuted/50 rounded-lg flex items-center justify-center cursor-not-allowed flex-shrink-0"
            >
              <Mic size={16} />
            </button>
            <button
              onClick={() => handleSendMessage(input)}
              disabled={sending || !input.trim()}
              title={sending ? 'Assistant is responding…' : 'Send message'}
              className={cn(
                'w-8 h-8 rounded-lg flex items-center justify-center transition-all flex-shrink-0',
                sending
                  ? 'bg-claude-text/40 text-white cursor-not-allowed'
                  : 'bg-claude-accent hover:bg-claude-accentHover text-claude-accentText disabled:opacity-30'
              )}
            >
              {sending ? <Loader2 size={14} className="animate-spin" /> : <Send size={14} />}
            </button>
          </div>
        </div>
      </div>
    </div>
  )
}

export default function AiChat() {
  const { user, profile } = useAuth()
  const [searchParams, setSearchParams] = useSearchParams()
  const campaignId = searchParams.get('campaignId')
  const actionParam = searchParams.get('action')
  const sessionParam = searchParams.get('session')
  const prefillParam = searchParams.get('prefill')

  const [sessions, setSessions] = useState<ChatSessionSummary[]>([])
  const [currentSessionId, setCurrentSessionId] = useState<string | null>(null)
  const [sidebarOpen, setSidebarOpen] = useState(true)

  const [messages, setMessages] = useState<ChatMessage[]>([])
  const [input, setInput] = useState('')
  const [sending, setSending] = useState(false)
  const [loadingHistory, setLoadingHistory] = useState(true)
  const [pendingDraft, setPendingDraft] = useState<CampaignDraft | null>(null)
  const [traceSteps, setTraceSteps] = useState<TraceStep[]>([])
  const [revealedSteps, setRevealedSteps] = useState(0)
  const [thinkingLabel, setThinkingLabel] = useState('Understanding your request…')
  // Clickable choices for the assistant's latest one-at-a-time question —
  // lets the user tap an answer instead of always having to type it,
  // mirroring how Claude/ChatGPT surface multiple-choice clarifications.
  const [pendingOptions, setPendingOptions] = useState<string[]>([])

  // Rotate a friendly status line while we wait for the AI Manager's response
  useEffect(() => {
    if (!sending || traceSteps.length > 0) return
    const phrases = [
      'Understanding your request…',
      'Checking your business context…',
      'Working out the next step…',
      'Talking to the AI Manager…',
    ]
    let i = 0
    setThinkingLabel(phrases[0])
    const id = setInterval(() => {
      i = (i + 1) % phrases.length
      setThinkingLabel(phrases[i])
    }, 1600)
    return () => clearInterval(id)
  }, [sending, traceSteps.length])

  // Upload fields
  const [attachedImage, setAttachedImage] = useState<string | null>(null)
  const [attachedFileName, setAttachedFileName] = useState<string | null>(null)

  const scrollRef = useRef<HTMLDivElement>(null)
  const fileInputRef = useRef<HTMLInputElement>(null)
  const textareaRef = useRef<HTMLTextAreaElement>(null)

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTo({ top: scrollRef.current.scrollHeight, behavior: 'smooth' })
    }
  }, [messages, sending])

  // Picks up a message handed off from elsewhere in the dashboard (e.g. the
  // Landing Page Template Library's "Use Template" button) — loads it into
  // the composer so the user can review/edit before sending, rather than
  // firing an AI action with no confirmation step.
  useEffect(() => {
    if (!prefillParam) return
    setInput(prefillParam)
    requestAnimationFrame(() => textareaRef.current?.focus())
    setSearchParams(prev => {
      const next = new URLSearchParams(prev)
      next.delete('prefill')
      return next
    }, { replace: true })
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [prefillParam])

  const fetchPendingDraft = useCallback(async () => {
    try {
      if (!user?.id) return
      const drafts = await getPendingDraft(user.id)
      if (drafts && drafts.length > 0) {
        setPendingDraft(drafts[0] as CampaignDraft)
      } else {
        setPendingDraft(null)
      }
    } catch (e) {
      console.error(e)
    }
  }, [user])

  const greetingFor = useCallback((forCampaignId: string | null) => {
    if (forCampaignId) {
      return `I've opened the context for campaign ID "${forCampaignId}". Let me know how you'd like to adjust its daily budget, pause/resume it, swap ad creatives, or check its current telemetry performance.`
    }
    if (actionParam === 'create') {
      return `Ready to launch a new campaign! Tell me about your business, target audience, and primary campaign objective.`
    }
    return `Ready to launch your first campaign? Describe your business. We'll build everything for you.`
  }, [actionParam])

  const openSession = useCallback(async (sessionId: string) => {
    setLoadingHistory(true)
    setPendingOptions([])
    try {
      const { session, turns } = await getChatSessionHistory(sessionId)
      setCurrentSessionId(session.id)
      if (turns.length > 0) {
        setMessages(turns.map(t => ({ role: t.role, content: t.content, id: t.id, created_at: t.created_at })))
      } else {
        setMessages([{ role: 'assistant', content: greetingFor(session.campaign_id) }])
      }
      setSearchParams(prev => {
        const next = new URLSearchParams(prev)
        next.set('session', session.id)
        return next
      }, { replace: true })
      fetchPendingDraft()
    } catch (e) {
      console.error(e)
    } finally {
      setLoadingHistory(false)
    }
  }, [greetingFor, setSearchParams, fetchPendingDraft])

  const refreshSessions = useCallback(async () => {
    try {
      const list = await listChatSessions()
      setSessions(list)
      return list
    } catch (e) {
      console.error(e)
      return []
    }
  }, [])

  // Initial load: figure out which session to open — a campaign's own chat
  // if we arrived via "Open chat" on a specific campaign, a deep-linked
  // session from the URL, or the most recently active chat. Falls back to
  // an empty/new state only if the business has no chats at all yet.
  useEffect(() => {
    if (!user) return
    let cancelled = false

    ;(async () => {
      setLoadingHistory(true)
      const list = await refreshSessions()
      if (cancelled) return

      if (campaignId) {
        const existing = list.find(s => s.campaign_id === campaignId)
        if (existing) {
          await openSession(existing.id)
        } else {
          const created = await createChatSession(campaignId)
          setSessions(prev => [created, ...prev])
          await openSession(created.id)
        }
        return
      }

      if (sessionParam && list.some(s => s.id === sessionParam)) {
        await openSession(sessionParam)
        return
      }

      if (list.length > 0) {
        await openSession(list[0].id)
        return
      }

      // Brand new business — no chats yet. Show the empty/greeting state;
      // an actual session is created lazily on the first message sent.
      setCurrentSessionId(null)
      setMessages([])
      setLoadingHistory(false)
    })()

    return () => { cancelled = true }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [user])

  const handleNewChat = async () => {
    setSending(true)
    try {
      const created = await createChatSession(campaignId ?? undefined)
      setSessions(prev => [created, ...prev])
      setCurrentSessionId(created.id)
      setMessages([{ role: 'assistant', content: `Fresh canvas loaded. What business objective or campaign adjustment should we handle next?` }])
      setPendingDraft(null)
      setTraceSteps([])
      setPendingOptions([])
      setSearchParams(prev => {
        const next = new URLSearchParams(prev)
        next.set('session', created.id)
        return next
      }, { replace: true })
    } catch (e) {
      console.error(e)
    } finally {
      setSending(false)
    }
  }

  const handleDeleteSession = async (sessionId: string, e: React.MouseEvent) => {
    e.stopPropagation()
    try {
      await deleteChatSession(sessionId)
      const remaining = sessions.filter(s => s.id !== sessionId)
      setSessions(remaining)
      if (sessionId === currentSessionId) {
        if (remaining.length > 0) {
          await openSession(remaining[0].id)
        } else {
          setCurrentSessionId(null)
          setMessages([])
        }
      }
    } catch (e2) {
      console.error(e2)
    }
  }

  const handleSendMessage = async (text: string) => {
    let messageText = text.trim()
    if (!messageText || sending) return

    if (campaignId && !messageText.includes('[Context:')) {
      messageText = `[Context: Campaign ID ${campaignId}] ${messageText}`
    }

    if (attachedFileName) {
      messageText = `[Attached Asset: ${attachedFileName}] ${messageText}`
    }

    setInput('')
    setAttachedImage(null)
    setAttachedFileName(null)
    setPendingOptions([])
    setMessages(prev => [...prev, { role: 'user', content: messageText }])
    setSending(true)
    setTraceSteps([])
    setRevealedSteps(0)

    try {
      const result = await askAiManager(messageText, true, currentSessionId)
      const steps = (result.trace && Array.isArray(result.trace)) ? (result.trace as TraceStep[]) : []

      if (steps.length > 0) {
        setTraceSteps(steps)
        // Reveal each step one at a time so it reads like Claude's live working trace
        for (let i = 0; i < steps.length; i++) {
          await new Promise(resolve => setTimeout(resolve, 450))
          setRevealedSteps(i + 1)
        }
        await new Promise(resolve => setTimeout(resolve, 350))
      }

      setMessages(prev => [...prev, { role: 'assistant', content: result.message }])
      setTraceSteps([])
      setRevealedSteps(0)
      setPendingOptions(result.awaiting_user ? (result.options ?? []) : [])

      // The very first message of a brand-new chat creates its session
      // server-side (session_id was null) — pick that up now so every
      // message after this one stays in the same chat.
      if (!currentSessionId && result.session_id) {
        setCurrentSessionId(result.session_id)
        setSearchParams(prev => {
          const next = new URLSearchParams(prev)
          next.set('session', result.session_id)
          return next
        }, { replace: true })
      }

      // Keep the sidebar's titles/ordering in sync (sessions get
      // auto-titled server-side from the first message, and "updated_at"
      // changes on every turn).
      refreshSessions()

      // Check if campaign draft details were finalized
      await fetchPendingDraft()
    } catch (err) {
      const msg = err instanceof AiManagerError ? err.message : 'Something went wrong communicating with the AI Manager.'
      setMessages(prev => [...prev, { role: 'error', content: msg }])
    } finally {
      setSending(false)
    }
  }

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (file) {
      setAttachedFileName(file.name)
      const reader = new FileReader()
      reader.onloadend = () => {
        setAttachedImage(reader.result as string)
      }
      reader.readAsDataURL(file)
    }
  }

  const handleApproveDraft = async (reason = 'Approved') => {
    if (!pendingDraft) return
    setSending(true)
    try {
      const decidedBy = profile?.full_name ?? user!.email ?? 'User'
      await approveDraft(pendingDraft.id, decidedBy, reason)
      
      setMessages(prev => [
        ...prev,
        { role: 'user', content: `Approved draft: ${pendingDraft.strategy.campaign_name}` },
        { role: 'assistant', content: `Perfect! I've approved and published campaign "${pendingDraft.strategy.campaign_name}" to your Meta Account. You can monitor its live metrics in the Dashboard now.` }
      ])
      setPendingDraft(null)
    } catch (err) {
      const msg = err instanceof AiManagerError ? err.message : 'Approval request failed.'
      setMessages(prev => [...prev, { role: 'error', content: msg }])
      console.error(err)
    } finally {
      setSending(false)
    }
  }

  const handleRejectDraft = async (reason: string) => {
    if (!pendingDraft || !reason.trim()) return
    setSending(true)
    try {
      const decidedBy = profile?.full_name ?? user!.email ?? 'User'
      await rejectDraft(pendingDraft.id, decidedBy, reason)

      setMessages(prev => [
        ...prev,
        { role: 'user', content: `Rejected draft with changes: ${reason}` },
        { role: 'assistant', content: `I've registered your feedback: "${reason}". I am reworking the campaign parameters now. Let me know what specific changes to focus on.` }
      ])
      setPendingDraft(null)
    } catch (err) {
      const msg = err instanceof AiManagerError ? err.message : 'Rejection request failed.'
      setMessages(prev => [...prev, { role: 'error', content: msg }])
      console.error(err)
    } finally {
      setSending(false)
    }
  }

  // Quick suggestions
  const suggestedPrompts = [
    { label: 'gym memberships', text: 'I need more local gym memberships. Draft a target strategy.' },
    { label: 'clinic campaign', text: 'Launch a campaign for my clinic.' },
    { label: 'adjust budget', text: 'Increase daily budget of campaign to ₹1000.' },
    { label: 'pause ads', text: 'Pause my active clinic campaign.' }
  ]

  // Parse trace steps into simple text list
  const getTraceStepTitle = (step: TraceStep) => {
    const dec = step.decision
    if (dec.action === 'call_tool') {
      // Keys must match app/tools/registry.py's actual Tool.name values —
      // never show the raw internal tool name in the chat UI (spec: chat
      // shows only friendly labels, e.g. "Generating landing page..." for
      // landing_page_tool, never the tool name itself).
      const toolMap: Record<string, string> = {
        business_analysis_tool: 'Audit & Market Research',
        strategy_tool: 'Designing Ad Structure',
        creative_tool: 'Copywriting & Graphics Gen',
        landing_page_tool: 'Generating landing page...',
        meta_ads_tool: 'Provisioning Meta Campaign',
        analytics_tool: 'Retrieving Ads Metrics',
        knowledge_tool: 'Searching Knowledge Base',
        memory_tool: 'Updating Business Memory',
        compliance_tool: 'Ad Safety Audit',
        support_tool: 'Submitting Ticket',
      }
      return toolMap[dec.tool] ?? 'Working on it…'
    }
    if (dec.action === 'ask_user') return 'Asking User Clarification'
    if (dec.action === 'final_response') return 'Synthesizing Response'
    return 'Cognitive Step'
  }

  const isEmpty = messages.length === 0 && !loadingHistory && !currentSessionId

  const isLastMessageAssistant = messages.length > 0 && messages[messages.length - 1].role === 'assistant'

  return (
    <>
      <Helmet><title>Conversational Workspace — LeadPilot</title></Helmet>

      <div className="h-[calc(100vh-3.5rem)] md:h-screen -m-4 sm:-m-6 lg:-m-8 flex bg-claude-bg">
        {/* Previous chats sidebar — this is the actual data source now (a
            real per-business list of server-side sessions), not something
            loaded from localStorage that only the current browser can see. */}
        {sidebarOpen && (
          <div className="hidden sm:flex w-64 flex-shrink-0 border-r border-claude-border bg-white/60 flex-col">
            <div className="flex items-center justify-between px-3 py-3 border-b border-claude-border">
              <span className="text-xs font-semibold text-claude-textMuted uppercase tracking-wide">Chats</span>
              <button
                onClick={() => setSidebarOpen(false)}
                className="w-6 h-6 rounded-md text-claude-textMuted hover:text-claude-text flex items-center justify-center"
                title="Hide sidebar"
              >
                <PanelLeftClose size={14} />
              </button>
            </div>
            <div className="p-2">
              <button
                onClick={handleNewChat}
                className="w-full flex items-center gap-2 text-xs font-medium text-claude-text bg-white border border-claude-border hover:border-claude-accent rounded-lg px-3 py-2 transition-colors"
              >
                <PenSquare size={13} />
                New chat
              </button>
            </div>
            <div className="flex-1 overflow-y-auto custom-scrollbar px-2 pb-2 space-y-1">
              {sessions.length === 0 && (
                <p className="text-xs text-claude-textMuted px-2 py-3">No previous chats yet.</p>
              )}
              {sessions.map(s => (
                <button
                  key={s.id}
                  onClick={() => openSession(s.id)}
                  className={cn(
                    'w-full group flex items-start gap-2 text-left px-2.5 py-2 rounded-lg text-xs transition-colors',
                    s.id === currentSessionId
                      ? 'bg-claude-accentSoft text-claude-text'
                      : 'text-claude-textMuted hover:bg-claude-bg hover:text-claude-text'
                  )}
                >
                  {s.campaign_id ? <Megaphone size={13} className="mt-0.5 flex-shrink-0" /> : <MessageSquare size={13} className="mt-0.5 flex-shrink-0" />}
                  <span className="flex-1 min-w-0 truncate">{s.title}</span>
                  <span
                    onClick={e => handleDeleteSession(s.id, e)}
                    className="opacity-0 group-hover:opacity-100 text-claude-textMuted hover:text-red-500 flex-shrink-0"
                    title="Delete chat"
                  >
                    <Trash2 size={12} />
                  </span>
                </button>
              ))}
            </div>
          </div>
        )}

        <div className="flex-1 flex flex-col min-w-0">
          {/* Empty state — centered greeting, Claude home-screen style */}
          {isEmpty ? (
            <div className="flex-1 flex flex-col items-center justify-center px-4">
              <div className="w-full max-w-2xl mx-auto">
                <div className="flex items-center gap-2.5 justify-center mb-8">
                  <div className="w-9 h-9 rounded-xl bg-claude-accent flex items-center justify-center">
                    <Sparkles size={17} className="text-claude-accentText" />
                  </div>
                  <h1 className="text-[26px] font-medium text-claude-text">
                    {campaignId
                      ? 'Reviewing your campaign'
                      : `Hi ${profile?.full_name?.split(' ')[0] ?? 'there'}, ready to grow?`}
                  </h1>
                </div>

                <Composer
                  input={input}
                  setInput={setInput}
                  sending={sending}
                  attachedImage={attachedImage}
                  setAttachedImage={setAttachedImage}
                  attachedFileName={attachedFileName}
                  setAttachedFileName={setAttachedFileName}
                  fileInputRef={fileInputRef}
                  textareaRef={textareaRef}
                  handleFileChange={handleFileChange}
                  handleSendMessage={handleSendMessage}
                />

                <div className="flex flex-wrap gap-2 justify-center mt-4">
                  {suggestedPrompts.map(p => (
                    <button
                      key={p.label}
                      onClick={() => {
                        setInput(p.text)
                        requestAnimationFrame(() => textareaRef.current?.focus())
                      }}
                      className="px-3.5 py-1.5 text-[13px] rounded-full border border-claude-border bg-white text-claude-textMuted hover:text-claude-accent hover:border-claude-accent/40 transition-colors"
                    >
                      {p.label}
                    </button>
                  ))}
                </div>
              </div>
            </div>
          ) : (
            <>
              {/* Top bar — Info + New chat (working status now lives inline in the chat below) */}
              <div className="flex items-center justify-between px-4 sm:px-6 py-2.5 border-b border-claude-border">
                <div className="flex items-center gap-2">
                  {!sidebarOpen && (
                    <button
                      onClick={() => setSidebarOpen(true)}
                      className="w-7 h-7 rounded-full border border-claude-border text-claude-textMuted hover:text-claude-text flex items-center justify-center"
                      title="Show chats"
                    >
                      <PanelLeft size={14} />
                    </button>
                  )}
                  <button
                    title="Session info"
                    className="w-7 h-7 rounded-full border border-claude-border text-claude-textMuted hover:text-claude-text flex items-center justify-center"
                  >
                    <Info size={14} />
                  </button>
                </div>
                <div className="flex items-center gap-2">
                  <button
                    onClick={handleNewChat}
                    className="flex items-center gap-1.5 text-xs font-medium text-claude-text bg-white border border-claude-border hover:border-claude-accent rounded-lg px-3 py-1.5 transition-colors"
                  >
                    <PenSquare size={13} />
                    New chat
                  </button>
                </div>
              </div>

              {/* Message scroll area — centered column like Claude's chat */}
              <div ref={scrollRef} className="flex-1 overflow-y-auto custom-scrollbar">
                <div className="max-w-3xl mx-auto px-4 sm:px-6 py-8 space-y-6">
                  {loadingHistory ? (
                    <div className="space-y-4 py-8">
                      <div className="h-10 w-2/3 bg-claude-border/50 rounded-xl animate-pulse" />
                      <div className="h-10 w-1/3 bg-claude-border/50 rounded-xl animate-pulse ml-auto" />
                      <div className="h-16 w-1/2 bg-claude-border/50 rounded-xl animate-pulse" />
                    </div>
                  ) : (
                    messages.map((m, idx) => (
                      <div
                        key={idx}
                        className={cn(
                          'flex',
                          m.role === 'user' ? 'justify-end' : 'justify-start',
                          idx === messages.length - 1 && 'animate-fade-up'
                        )}
                        style={idx === messages.length - 1 ? { animationDuration: '0.4s' } : undefined}
                      >
                        {m.role === 'user' ? (
                          <div className="max-w-[80%] bg-claude-accentSoft text-claude-text rounded-2xl px-4 py-2.5 text-[15px] leading-relaxed">
                            <p className="whitespace-pre-wrap">{m.content}</p>
                          </div>
                        ) : (
                          <div className={cn(
                            'max-w-[80%] text-[15px] leading-relaxed',
                            m.role === 'error' ? 'text-red-600' : 'text-claude-text'
                          )}>
                            <p className="whitespace-pre-wrap">{m.content}</p>
                          </div>
                        )}
                      </div>
                    ))
                  )}

                  {/* Clickable answer options for the assistant's latest
                      question — the Manager now asks one question at a
                      time and can offer short choices instead of forcing
                      free text, similar to Claude's own clarifying-question
                      buttons. */}
                  {!sending && pendingOptions.length > 0 && isLastMessageAssistant && (
                    <div className="flex flex-wrap gap-2 animate-fade-up" style={{ animationDuration: '0.3s' }}>
                      {pendingOptions.map(opt => (
                        <button
                          key={opt}
                          onClick={() => handleSendMessage(opt)}
                          className="px-3.5 py-1.5 text-[13px] rounded-full border border-claude-border bg-white text-claude-text hover:border-claude-accent hover:text-claude-accent transition-colors"
                        >
                          {opt}
                        </button>
                      ))}
                    </div>
                  )}

                  {/* Inline "assistant is working" indicator — lives in the chat flow, not a top pill */}
                  {sending && traceSteps.length === 0 && (
                    <div className="flex items-center gap-2.5 text-claude-textMuted text-[13px] animate-fade-in">
                      <span className="flex gap-1">
                        <span className="w-1.5 h-1.5 bg-claude-accent/70 rounded-full typing-dot" />
                        <span className="w-1.5 h-1.5 bg-claude-accent/70 rounded-full typing-dot" />
                        <span className="w-1.5 h-1.5 bg-claude-accent/70 rounded-full typing-dot" />
                      </span>
                      <span key={thinkingLabel} className="animate-fade-in">{thinkingLabel}</span>
                    </div>
                  )}

                  {/* Live reasoning trace — steps reveal one by one, like Claude working through a task */}
                  {sending && traceSteps.length > 0 && (
                    <div className="max-w-[85%] border border-claude-border bg-white rounded-xl px-4 py-3">
                      <div className="space-y-2.5">
                        {traceSteps.slice(0, revealedSteps).map((step, idx) => {
                          const isLast = idx === revealedSteps - 1
                          const isCurrent = isLast && revealedSteps < traceSteps.length
                          return (
                            <div
                              key={idx}
                              className="flex items-center gap-2.5 text-[13px] animate-fade-up"
                              style={{ animationDuration: '0.35s' }}
                            >
                              {isCurrent ? (
                                <Loader2 size={13} className="text-claude-accent animate-spin flex-shrink-0" />
                              ) : (
                                <CheckCircle2 size={13} className="text-emerald-500 flex-shrink-0" />
                              )}
                              <span className={isCurrent ? 'text-claude-text font-medium' : 'text-claude-textMuted'}>
                                {getTraceStepTitle(step)}
                              </span>
                            </div>
                          )
                        })}
                      </div>
                    </div>
                  )}

                  {/* Inline campaign draft approval card */}
                  {pendingDraft && (
                    <div className="border border-claude-border bg-white rounded-2xl overflow-hidden shadow-sm">
                      <div className="px-4 py-3 border-b border-claude-border flex items-center justify-between bg-claude-bg/60">
                        <div>
                          <span className="text-[10px] px-2 py-0.5 bg-amber-50 border border-amber-200 text-amber-600 rounded-full font-semibold uppercase">Pending review</span>
                          <h3 className="text-sm font-semibold text-claude-text mt-1.5">{pendingDraft.strategy.campaign_name}</h3>
                          <p className="text-claude-textMuted text-xs">{pendingDraft.strategy.objective} · ₹{pendingDraft.strategy.daily_budget}/day</p>
                        </div>
                      </div>
                      <div className="p-4 space-y-3">
                        <p className="text-xs text-claude-textMuted leading-relaxed">
                          <span className="font-medium text-claude-text">Audience: </span>
                          {pendingDraft.strategy.target_audience}
                        </p>
                        <p className="text-xs text-claude-text bg-claude-bg rounded-lg p-3 border border-claude-border leading-relaxed">
                          {pendingDraft.creative.primary_text}
                        </p>
                        {pendingDraft.landing_page && (
                          <div className="flex items-center gap-2 text-xs text-claude-textMuted">
                            <FileText size={13} className="text-claude-accent" />
                            {pendingDraft.landing_page.name} ({pendingDraft.landing_page.template_id})
                          </div>
                        )}
                        <div className="flex gap-2 pt-1">
                          <button
                            onClick={() => {
                              const r = prompt('Provide revision feedback notes to reject draft:')
                              if (r) handleRejectDraft(r)
                            }}
                            className="flex-1 py-2 bg-white border border-red-200 hover:bg-red-50 text-red-500 text-xs font-semibold rounded-xl transition-all flex items-center justify-center gap-1.5"
                          >
                            <XCircle size={13} />
                            Reject &amp; Rework
                          </button>
                          <button
                            onClick={() => handleApproveDraft()}
                            className="flex-1 py-2 bg-claude-accent hover:bg-claude-accentHover text-claude-accentText text-xs font-semibold rounded-xl transition-all flex items-center justify-center gap-1.5"
                          >
                            <CheckCircle2 size={13} />
                            Approve &amp; Publish
                          </button>
                        </div>
                      </div>
                    </div>
                  )}
                </div>
              </div>

              {/* Composer pinned at bottom */}
              <div className="px-4 pb-5 pt-2">
                <Composer
                  input={input}
                  setInput={setInput}
                  sending={sending}
                  attachedImage={attachedImage}
                  setAttachedImage={setAttachedImage}
                  attachedFileName={attachedFileName}
                  setAttachedFileName={setAttachedFileName}
                  fileInputRef={fileInputRef}
                  textareaRef={textareaRef}
                  handleFileChange={handleFileChange}
                  handleSendMessage={handleSendMessage}
                />
              </div>
            </>
          )}
        </div>
      </div>
    </>
  )
}
