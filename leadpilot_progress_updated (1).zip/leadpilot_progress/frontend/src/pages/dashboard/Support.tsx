import { Helmet } from 'react-helmet-async'
import { MessageCircle, Phone, Mail, HelpCircle, ExternalLink, ShieldCheck, Zap } from 'lucide-react'
import { useAuth } from '@/lib/AuthContext'

export default function Support() {
  const { profile } = useAuth()

  const whatsappNumber = '917879602982'
  const defaultMessage = encodeURIComponent(`Hello LeadPilot Support! I need help with my account (${profile?.full_name ?? 'User'}).`)
  const whatsappUrl = `https://wa.me/${whatsappNumber}?text=${defaultMessage}`

  const faqs = [
    {
      q: 'How do I add funds to my Meta Ad Account?',
      a: 'Navigate to Meta Fund (Billing) section in the dashboard, select your top-up amount, and click Request Deposit. Our team will verify and credit your balance immediately.'
    },
    {
      q: 'How do I connect my Facebook Business Manager & Ad Accounts?',
      a: 'Go to Meta Account settings page and click "Sign in with Facebook". Complete the OAuth permissions to link your Pages and Ad Accounts.'
    },
    {
      q: 'How does the AI Campaign Manager work?',
      a: 'Simply tell the AI Manager about your product or business objective in the AI Chat. It builds target audiences, writes high-converting ad copy, generates visual creatives, and constructs landing pages automatically.'
    },
    {
      q: 'What are the official support operating hours?',
      a: 'Our WhatsApp priority support team is active 24/7. Response times are usually under 5 minutes.'
    }
  ]

  return (
    <>
      <Helmet><title>Help &amp; WhatsApp Support — LeadPilot</title></Helmet>

      <div className="max-w-4xl mx-auto space-y-8 pb-12">
        {/* Header Banner */}
        <div className="bg-gradient-to-r from-emerald-600 to-teal-700 text-white rounded-3xl p-8 sm:p-10 shadow-xl relative overflow-hidden">
          <div className="absolute -right-10 -bottom-10 w-64 h-64 bg-white/10 rounded-full blur-2xl" />
          <div className="relative z-10 max-w-2xl space-y-4">
            <div className="inline-flex items-center gap-2 px-3 py-1 bg-white/20 backdrop-blur-md rounded-full text-xs font-semibold uppercase tracking-wider">
              <Zap size={14} className="text-yellow-300 fill-yellow-300" />
              24/7 Priority Support
            </div>
            <h1 className="text-3xl sm:text-4xl font-extrabold tracking-tight">Need Help? Chat Directly on WhatsApp</h1>
            <p className="text-emerald-100 text-sm sm:text-base leading-relaxed">
              Skip tickets and email waiting times! Connect directly with LeadPilot's senior campaign managers on WhatsApp for instant assistance.
            </p>
            <div className="pt-2">
              <a
                href={whatsappUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-2.5 px-6 py-3.5 bg-white text-emerald-800 hover:bg-emerald-50 font-bold rounded-2xl shadow-lg transition-all transform hover:scale-[1.02] active:scale-[0.98]"
              >
                <MessageCircle size={22} className="text-emerald-600 fill-emerald-600" />
                Chat on WhatsApp Now
                <ExternalLink size={16} />
              </a>
            </div>
          </div>
        </div>

        {/* Contact Method Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
          <a
            href={whatsappUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="glass rounded-2xl p-6 space-y-3 border border-emerald-500/30 hover:border-emerald-500/60 transition-all bg-emerald-500/5 group"
          >
            <div className="w-12 h-12 rounded-xl bg-emerald-500/20 text-emerald-400 flex items-center justify-center group-hover:scale-110 transition-transform">
              <MessageCircle size={24} />
            </div>
            <h3 className="text-lg font-semibold text-white">WhatsApp Support</h3>
            <p className="text-slate-400 text-xs leading-relaxed">Instant 1-on-1 chat with your assigned Meta Ads manager.</p>
            <span className="text-emerald-400 text-xs font-semibold flex items-center gap-1 pt-1">
              +91 7879602982 <ExternalLink size={12} />
            </span>
          </a>

          <a
            href="tel:+917879602982"
            className="glass rounded-2xl p-6 space-y-3 border border-white/10 hover:border-brand-500/50 transition-all group"
          >
            <div className="w-12 h-12 rounded-xl bg-brand-500/20 text-brand-400 flex items-center justify-center group-hover:scale-110 transition-transform">
              <Phone size={24} />
            </div>
            <h3 className="text-lg font-semibold text-white">Direct Phone Call</h3>
            <p className="text-slate-400 text-xs leading-relaxed">Speak directly with tech &amp; campaign operations team.</p>
            <span className="text-brand-400 text-xs font-semibold flex items-center gap-1 pt-1">
              Call Now <ExternalLink size={12} />
            </span>
          </a>

          <a
            href="mailto:support@leadpilot.in"
            className="glass rounded-2xl p-6 space-y-3 border border-white/10 hover:border-violet-500/50 transition-all group"
          >
            <div className="w-12 h-12 rounded-xl bg-violet-500/20 text-violet-400 flex items-center justify-center group-hover:scale-110 transition-transform">
              <Mail size={24} />
            </div>
            <h3 className="text-lg font-semibold text-white">Email Support</h3>
            <p className="text-slate-400 text-xs leading-relaxed">Send detailed campaign briefs or documentation.</p>
            <span className="text-violet-400 text-xs font-semibold flex items-center gap-1 pt-1">
              support@leadpilot.in <ExternalLink size={12} />
            </span>
          </a>
        </div>

        {/* FAQs */}
        <div className="glass rounded-2xl p-8 border border-white/10 space-y-6">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-brand-500/20 text-brand-400 flex items-center justify-center">
              <HelpCircle size={20} />
            </div>
            <div>
              <h2 className="text-xl font-bold text-white">Frequently Asked Questions</h2>
              <p className="text-slate-400 text-xs">Quick answers to common questions</p>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {faqs.map((faq, idx) => (
              <div key={idx} className="p-4 rounded-xl bg-white/5 border border-white/5 space-y-2">
                <h4 className="text-sm font-semibold text-white flex items-start gap-2">
                  <ShieldCheck size={16} className="text-brand-400 flex-shrink-0 mt-0.5" />
                  {faq.q}
                </h4>
                <p className="text-xs text-slate-400 leading-relaxed pl-6">{faq.a}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </>
  )
}
