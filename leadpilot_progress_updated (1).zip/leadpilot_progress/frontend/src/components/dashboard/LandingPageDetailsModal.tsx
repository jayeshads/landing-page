import { useState } from 'react'
import { ExternalLink, Copy, Check, Palette, MousePointerClick, Layers } from 'lucide-react'
import ModalShell from './campaigns/modals/ModalShell'

// Phase 5 task 5.3 — post-generation details modal. Surfaces exactly what
// the AI actually generated for a landing page: the live/preview link
// (button link), the brand it was built with, the brand colors it was
// rendered in, and the CTA button copy. Everything here comes straight off
// the `landing_pages` row (content_json / brand_json / template_id / url),
// so nothing shown is fabricated — fields the row doesn't have (e.g. a
// legacy page generated before brand_json existed) are shown as "Not set"
// rather than guessed.

export interface LandingPageDetails {
  id: string
  name: string
  status: 'draft' | 'live' | 'paused'
  template_id?: string | null
  url?: string | null
  preview_url?: string | null
  content?: {
    headline?: string
    subheadline?: string
    offer?: string
    cta?: string
  } | null
  brand?: {
    business_name?: string
    primary_color?: string
    secondary_color?: string
  } | null
}

interface Props {
  page: LandingPageDetails
  onClose: () => void
}

function ColorSwatch({ label, hex }: { label: string; hex?: string }) {
  return (
    <div className="flex items-center gap-2.5 bg-dark-800/60 rounded-xl p-3">
      <div
        className="w-8 h-8 rounded-lg border border-white/10 flex-shrink-0"
        style={{ backgroundColor: hex || '#1e293b' }}
      />
      <div className="min-w-0">
        <p className="text-slate-500 text-[10px] uppercase font-semibold">{label}</p>
        <p className="text-white text-xs font-mono truncate">{hex || 'Not set'}</p>
      </div>
    </div>
  )
}

export default function LandingPageDetailsModal({ page, onClose }: Props) {
  const [copied, setCopied] = useState(false)

  const buttonLink = page.url || page.preview_url || (page.id ? `/lp/${page.id}` : null)
  const fullLink = buttonLink && buttonLink.startsWith('/')
    ? `${window.location.origin}${buttonLink}`
    : buttonLink

  const handleCopy = async () => {
    if (!fullLink) return
    try {
      await navigator.clipboard.writeText(fullLink)
      setCopied(true)
      setTimeout(() => setCopied(false), 1500)
    } catch {
      // Clipboard API unavailable (e.g. insecure context) — link is still
      // visible/selectable, so this quietly does nothing further.
    }
  }

  return (
    <ModalShell title="Landing page details" subtitle={page.name} onClose={onClose} maxWidth="max-w-lg">
      <div className="space-y-5">
        {/* Button link */}
        <div>
          <p className="text-slate-500 text-[10px] uppercase font-semibold mb-1.5 flex items-center gap-1.5">
            <ExternalLink size={11} /> Page link
          </p>
          {fullLink ? (
            <div className="flex items-center gap-2 bg-dark-800/60 rounded-xl p-3">
              <span className="text-white text-xs font-mono truncate flex-1">{fullLink}</span>
              <button
                onClick={handleCopy}
                title="Copy link"
                className="text-slate-400 hover:text-white flex-shrink-0"
              >
                {copied ? <Check size={14} className="text-green-400" /> : <Copy size={14} />}
              </button>
              <a
                href={fullLink}
                target="_blank"
                rel="noopener noreferrer"
                title="Open page"
                className="text-brand-400 hover:text-brand-300 flex-shrink-0"
              >
                <ExternalLink size={14} />
              </a>
            </div>
          ) : (
            <p className="text-slate-600 text-xs bg-dark-800/60 rounded-xl p-3">
              Not published yet — publish this page to get a live link.
            </p>
          )}
        </div>

        {/* Brand */}
        <div>
          <p className="text-slate-500 text-[10px] uppercase font-semibold mb-1.5 flex items-center gap-1.5">
            <Layers size={11} /> Brand
          </p>
          <div className="bg-dark-800/60 rounded-xl p-3 flex items-center justify-between">
            <span className="text-white text-sm font-medium">
              {page.brand?.business_name || 'Not set'}
            </span>
            {page.template_id && (
              <span className="text-[10px] px-2 py-0.5 bg-white/5 border border-white/10 text-slate-400 rounded-full font-mono">
                {page.template_id}
              </span>
            )}
          </div>
        </div>

        {/* Colors */}
        <div>
          <p className="text-slate-500 text-[10px] uppercase font-semibold mb-1.5 flex items-center gap-1.5">
            <Palette size={11} /> Colors
          </p>
          <div className="grid grid-cols-2 gap-2.5">
            <ColorSwatch label="Primary" hex={page.brand?.primary_color} />
            <ColorSwatch label="Secondary" hex={page.brand?.secondary_color} />
          </div>
        </div>

        {/* CTA */}
        {page.content?.cta && (
          <div>
            <p className="text-slate-500 text-[10px] uppercase font-semibold mb-1.5 flex items-center gap-1.5">
              <MousePointerClick size={11} /> Call to action
            </p>
            <div className="bg-dark-800/60 rounded-xl p-3">
              <span className="inline-block px-3 py-1.5 bg-brand-600 text-white text-xs font-semibold rounded-lg">
                {page.content.cta}
              </span>
              {page.content.offer && (
                <p className="text-slate-400 text-xs mt-2">{page.content.offer}</p>
              )}
            </div>
          </div>
        )}
      </div>
    </ModalShell>
  )
}
